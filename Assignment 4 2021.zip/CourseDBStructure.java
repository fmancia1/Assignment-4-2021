import java.util.LinkedList;
import java.util.ArrayList;

class CourseDBStructure implements CourseDBStructureInterface {
  LinkedList<CourseDBElement>[] hashTable;
  public CourseDBStructure(int size) {
    hashTable = new LinkedList<CourseDBElement>[size];
    for (int i = 0; i < size; i++)
      hashTable[i] = new LinkedList<CourseDBElement>();
  }
  public CourseDBStructure(String test, int size) {
    CourseDBStructure(size);
  }
  public void add(CourseDBElement element) {
    int i = hash(element.crn);
    if (!hashTable[i].contains(element)) {
      hashTable[i].addFirst(element);
    }
  }
  /**
   * get gets the crn.
   * @param crn is the key.
   * @return the element. If not throw exception
   *
   */
  public CourseDBElement get(int crn) throws IOException {
    int i = hash(crn);
    for (CourseDBElement element : hashTable[i]) {
      if (element.crn == crn)
        return element;
    }
    throw new IOException("The crn is not in the hashTable");
  }
  /**
   * getTableSize gives the lenght of the hashTable.
   * @return hastable lenght.
   *
   */
	public int getTableSize() {
    return hashTable[i].lenght();
  }
  /**
   * hash gives the index.
   * @param crn.
   * @return the index.
   *
   */
  public int hash(int crn) {
    return crn % hashTable.length(); 
  }
}