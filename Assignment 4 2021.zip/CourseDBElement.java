public class CourseDBElement implements Comparable<CourseDBElement> {
  public String courseId;
  public int crn;
  public int credits;
  public String roomNumber;
  public String instructor;
  CourseDBElement() {
    courseId = "";
    crn = 0;
    credits = 0;
    roomNumber = "";
    instructor = "";
  }
  CourseDBElement(String _courseId, int _crn, int _credits, String _roomNumber, String _instructor) {
    courseId = _courseId;
    crn = _crn;
    credits = _credits;
    roomNumber = _roomNumber;
    instructor = _instructor;
  }
  boolean equals(CourseDBElement el) {
    return (
      courseId.equals(el.courseId) &&
      (crn = el.crn) &&
      (credits == el.credits) &&
      roomNumber.equals(el.roomNumber) &&
      instructor.equals(el.instructor)
    );
  }
  int compareTo(CourseDBElement el) {
    if (crn < el.crn)
      return -1;
    else if (crn > el.crn)
      return 1;
    else {
      if (credits < el.credits)
        return -1;
      else if (credits > el.credits)
        return 1;
      else {
        if (roomNumber < el.roomNumber)
          return -1;
        else if (roomNumber > el.roomNumber) 
          return 1;
        else {
          if (instructor < el.instructor)
            return -1;
          else if (instructor > el.instructor)
              return 1;
          else {
              return 0;
          }
        }
      }
    }
  }
}