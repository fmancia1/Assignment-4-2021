public class CourseDBElement implements Comparable<CourseDBElement> {
  public String courseId;
  public int crn;
  public int credits;
  public String roomNumber;
  public String instructor;
  public CourseDBElement() {
    courseId = "";
    crn = 0;
    credits = 0;
    roomNumber = "";
    instructor = "";
  }
  public CourseDBElement(String _courseId, int _crn, int _credits, String _roomNumber, String _instructor) {
    courseId = _courseId;
    crn = _crn;
    credits = _credits;
    roomNumber = _roomNumber;
    instructor = _instructor;
  }
  public boolean equals(CourseDBElement el) {
    return (
      courseId.equals(el.courseId) &&
      (crn == el.crn) &&
      (credits == el.credits) &&
      roomNumber.equals(el.roomNumber) &&
      instructor.equals(el.instructor)
    );
  }
  public int compareTo(CourseDBElement el) {
    if (crn < el.crn)
      return -1;
    else if (crn > el.crn)
      return 1;
    else {
      if (credits < el.credits)
        return -1;
      else if (credits > el.credits)
        return 1;
      else {
        if (roomNumber.compareTo(el.roomNumber) == -1)
          return -1;
        else if (roomNumber.compareTo(el.roomNumber) == 1) 
          return 1;
        else {
          if (instructor.compareTo(el.instructor) == -1)
            return -1;
          else if (instructor.compareTo(el.instructor) == 1)
              return 1;
          else {
              return 0;
          }
        }
      }
    }
  }
  public String toString() {
    String s = "";
    s += "Course ID: " + courseId + "\n";
    s += "CRN: " + Integer.toString(crn);
    s += "Credits: " + Integer.toString(credits);
    s += "Room Number: " + roomNumber;
    s += "Instructor: " + instructor;
    return s;
  }
}