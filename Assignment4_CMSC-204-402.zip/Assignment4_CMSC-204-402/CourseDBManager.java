/**
* This is the CourseDBManager class
*
*
* @author Fatima Mancia
*
*/
import java.util.LinkedList;
import java.util.ArrayList;
import java.io.File;
import java.io.FileReader;
import java.io.FileNotFoundException; 
import java.io.IOException;
import java.io.BufferedReader;

class CourseDBManager implements CourseDBManagerInterface {
  CourseDBStructure dbStruct;
  public CourseDBManager() {
    dbStruct = new CourseDBStructure(100);
  }
  /**
   * add adds the new element.
   * @param id
   @param crn the key
   @param credits the number of credits
   @param roomNum the room number
   @param instructor instructor's name
   *
   */
  public void add(String id, int crn, int credits, String roomNum, String instructor) {
    CourseDBElement element = new CourseDBElement(id, crn, credits, roomNum, instructor);
    dbStruct.add(element);
  }
  /**
   * get gets the crn.
   * @param crn is the key
   * @return the crn number. If not throw exception
   *
   */
  public CourseDBElement get(int crn) {
      CourseDBElement element;
      try {
        element = dbStruct.get(crn);
      }
      catch(Exception e) {
        element = null;
      }
      return element;
  }
  /**
   * readFile reads the txt given.
   * @param input 
   * @return element. If not throw exception
   *
   */
  public void readFile(File input) throws FileNotFoundException {
    FileReader fr = new FileReader(input);
    BufferedReader lineReader = new BufferedReader(fr);
    String line = null;
    while (true) {
      try {
        line = lineReader.readLine();
      }
      catch (Exception e) {
        line = null;
      }
      if (line == null)
        break;
      String[] fields = line.split(" ");
      CourseDBElement element = new CourseDBElement(
        fields[0],
        Integer.parseInt(fields[1]),
        Integer.parseInt(fields[2]),
        fields[3],
        fields[4]
      );
      dbStruct.add(element);
    }
  }
  
  public ArrayList<String> showAll() {
    ArrayList<String> list = new ArrayList<String>();
    for (int i = 0; i < dbStruct.hashTable.length; i++) {
      LinkedList<CourseDBElement> own = (LinkedList<CourseDBElement>) dbStruct.hashTable[i];
      for (CourseDBElement element: own)
        list.add(own.toString());
    }
    return list;
  }
}