import static org.junit.Assert.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
/**
 * This is the test file for the CourseDBManager
 * which is implemented from the CourseDBManagerInterface
 * 
 * @author Fatima Mancia
 *
 */
 public class CourseDBManager_STUDENT_Test {
   private CourseDBManagerInterface dataManager = new CourseDBManager();
   @Before
   public void setUp() throws Exception {
     dataManager = new CourseDBManager;
   }
   @After
   public void tearDown() throws Exception {
     dataManager = null;
   }
   @Test
   public void testAddToDB() {
    try {
			dataMgr.add("MATH182",30345,4,"SC150","Robert Green");
		}
		catch(Exception e) {
			fail("This should not have caused an Exception");
		}

   }
   /**
	 * Test for the showAll method
	 */
	@Test
	public void testShowAll() {
		dataMgr.add("CMSC203",30504,4,"SC450","Joey Bag-O-Donuts");
		dataMgr.add("CMSC203",30503,4,"SC450","Jill B. Who-Dunit");
		dataMgr.add("CMSC204",30559,4,"SC450","BillyBob Jones");
		ArrayList<String> list = dataMgr.showAll();
		
		assertEquals(list.get(0),"\nCourse:CMSC203 CRN:30503 Credits:4 Instructor:Jill B. Who-Dunit Room:SC450");
		assertEquals(list.get(1),"\nCourse:CMSC203 CRN:30504 Credits:4 Instructor:Joey Bag-O-Donuts Room:SC450");
		assertEquals(list.get(2),"\nCourse:CMSC204 CRN:30559 Credits:4 Instructor:BillyBob Jones Room:SC450");
			}
   /**
	 * Test for the read method
	 */
	@Test
	public void testRead() {
   try {
			File inputFile = new File("Test1.txt");
			PrintWriter inFile = new PrintWriter(inputFile);
			inFile.println("MATH182 30345 4 SC150 Robert Green");
			inFile.print("MATH182 30346 4 SC150 Jason Williams");
			
			inFile.close();
			dataMgr.readFile(inputFile);
			//System.out.println(dataMgr.showAll());
		} catch (Exception e) {
			fail("Should not have thrown an exception");
    }
  }
 }