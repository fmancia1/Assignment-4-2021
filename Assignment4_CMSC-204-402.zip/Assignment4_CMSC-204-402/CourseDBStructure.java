import java.util.LinkedList;
import java.util.ArrayList;

class CourseDBStructure implements CourseDBStructureInterface {
  public Object[] hashTable;
  public CourseDBStructure(int size) {
    hashTable = new Object[size];
    for (int i = 0; i < size; i++)
      hashTable[i] = (Object) new LinkedList<CourseDBElement>();
  }
  public CourseDBStructure(String test, int size) {
    this(size);
  }
  public void add(CourseDBElement element) {
    int i = hash(element.crn);
    LinkedList<CourseDBElement> own = (LinkedList<CourseDBElement>) hashTable[i];
    if (!own.contains(element)) {
      own.addFirst(element);
    }
  }
  /**
   * get gets the crn.
   * @param crn is the key.
   * @return the element. If not throw exception
   *
   */
  public CourseDBElement get(int crn) throws IOException {
    int i = hash(crn);
    LinkedList<CourseDBElement> own = (LinkedList<CourseDBElement>) hashTable[i];
    boolean flag = true;
    CourseDBElement ret = null;
    for (CourseDBElement element : own) {
      if (element.crn == crn) {
        ret = element;
        flag = false;
        break;
      }
    }
    if (flag)
      throw new IOException("element not found");
    return ret;
  }
  /**
   * getTableSize gives the lenght of the hashTable.
   * @return hastable lenght.
   *
   */
	public int getTableSize() {
    return hashTable.length;
  }
  /**
   * hash gives the index.
   * @param crn.
   * @return the index.
   *
   */
  public int hash(int crn) {
    return crn % hashTable.length; 
  }
}