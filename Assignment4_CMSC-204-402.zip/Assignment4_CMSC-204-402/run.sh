#!/bin/sh

CP="junit.jar:hamcrest-core.jar:."

# Compiling

javac CourseDBManager.java CourseDBManagerInterface.java CourseDBStructure.java CourseDBStructureInterface.java CourseDBElement.java # IOException.java
# javac -cp $CP SortedDoubleLinkedListTest.java SortedDoubleLinkedList.java SortedDoubleLinkedList_GFA_Test.java 
# javac -cp $CP DoubleLinkedListDriver.java 

# Running
# java -cp $CP org.junit.runner.JUnitCore BasicDoubleLinkedListTest
# java -cp $CP org.junit.runner.JUnitCore SortedDoubleLinkedListTest